INSERT INTO R_KANTOR (KANTOR,URAIAN_KANTOR) VALUES
	 ('Kantor Pusat','Kantor Pusat DJKN'),
	 ('Kanwil DJKN','Kantor Kanwil DJKN'),
	 ('Kanwil KPKNL','Kantor KPKNL');
