INSERT INTO r_departemen (DEPARTEMEN,URAIAN_DEPARTEMEN,created_at,updated_at) VALUES
	 ('L1','Sekretariat DJKN','2024-07-23 06:57:36','2024-07-23 06:57:36'),
	 ('L2','Kategori Layanan KPKNL DJKN','2024-07-23 06:57:30','2024-07-23 06:57:30'),
	 ('L2','Kategori Layanan Kanwil DJKN','2024-07-23 06:57:34','2024-07-23 06:57:34');
