INSERT INTO surveys (administrasi_layanan,prosedur_layanan,waktu_layanan,biaya_layanan,kompetensi_petugas,kesopanan_petugas,kualitas_sarana,ketersediaan_kanal,saran_kritik,created_at,updated_at,ID_LAYANAN,STATUS) VALUES
	 (1,4,4,5,5,5,5,5,'Tes','2024-08-08 03:28:01','2024-08-08 03:28:01',41,1),
	 (5,4,3,2,1,2,3,4,'Dapat ditingkatkan kembali','2024-08-08 03:38:32','2024-08-08 03:38:32',42,1);
