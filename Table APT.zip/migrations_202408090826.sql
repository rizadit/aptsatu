INSERT INTO migrations (migration,batch) VALUES
	 ('0001_01_01_000000_create_users_table',1),
	 ('0001_01_01_000001_create_cache_table',1),
	 ('0001_01_01_000002_create_jobs_table',1),
	 ('2024_07_03_024244_add_role_to_users_table',1),
	 ('2024_07_10_020311_create_r_kantor_table',1),
	 ('2024_07_10_021125_add_to_r_kantor_table',1),
	 ('2024_07_15_092435_create_r_pengunjungtable',1),
	 ('2024_07_16_001603_create_sessions_table',2),
	 ('2024_07_16_002214_create_r_user_table',3),
	 ('2024_07_16_002233_create_r_kantor_table',4);
INSERT INTO migrations (migration,batch) VALUES
	 ('2024_07_16_020502_create_r_departemen_table',5),
	 ('2024_07_16_020606_create_r_layanan_table',5),
	 ('2024_07_16_020637_create_r_jenis_tiket_table',5),
	 ('2024_07_16_025939_create_r_jenis_kanal',6),
	 ('2024_07_17_235303_create_t_layanan_table',7),
	 ('2024_07_17_235951_create_t_layanan_table',8),
	 ('2024_07_18_054307_create_r_jenis_kelamin',9),
	 ('2024_07_18_055152_create_r_jeniskelamin_table',10),
	 ('2024_07_18_055406_create_r_jenisprioritas_table',11),
	 ('2024_07_18_055629_create_r_jeniskanal_table',12);
INSERT INTO migrations (migration,batch) VALUES
	 ('2024_07_18_060753_remove_timestamps_from_r_jeniskanal_table',13),
	 ('2024_07_18_061205_create_r_jenispengguna_table',14),
	 ('2024_07_18_061903_create_r_jenistiket_table',15),
	 ('2024_07_23_061614_r_layanan_table',16),
	 ('2024_07_30_141135_create_surveys_table',17);
