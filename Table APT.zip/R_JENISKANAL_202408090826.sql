INSERT INTO R_JENISKANAL (URAIAN_JENISKANAL) VALUES
	 ('APT'),
	 ('Telepon'),
	 ('Surat elektronik/Web formulir'),
	 ('Whatsapp'),
	 ('Live chat');
