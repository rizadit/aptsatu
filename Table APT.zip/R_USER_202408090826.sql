INSERT INTO R_USER (USERNAME,PASSWORD,"ROLE",ID_KANTOR,CREATED_DATE,IS_AKTIF) VALUES
	 ('kantor','$2y$12$qHZOGAuZb7X3.qN6DzqX1.Hi5cqm.2Fu1g50ptjPIhulDKTKSxqwm','kantor',1,'2024-07-29 02:52:36',1),
	 ('adminpusat','$2y$12$9wCdbd5pbCFRlLtwE0qcMuweSoI.GwjkPX/f5B80u4B8Sks96cdhi','admin',1,'2024-07-29 02:52:36',1),
	 ('superadmin','$2y$12$WE4nI5iobVmpJHrcXgRD0OUeX.jaSZndyX.QRlYgEoF9NDdulvW0O','superadmin',1,'2024-07-29 02:52:36',1),
	 ('kanwil','$2y$12$/C5JvlFPB0/OsaoEMym4oOa79BKmFCV/HToRZGs.4Mpe3n2ZNv/9u','kantor',2,'2024-07-29 02:52:36',1),
	 ('adminkanwil','$2y$12$G2QVOoVQymBG2sbgE/KNYeEZ2apCOmzDzhXQugsOMchQ.V9qFOBFe','admin',2,'2024-07-29 02:52:36',1),
	 ('kpknl','$2y$12$jeVZZ4bjZ0W89PVQtRG2IuiyoML39e5vmexjNkOZIA7fmX9Kv0lTe','kantor',3,'2024-07-29 02:52:37',1),
	 ('adminkpknl','$2y$12$Zm7KtG9kqAlhwnyHiRcTg.Zseyt6MV.O8/15DltNIXW95NR77MpIW','admin',3,'2024-07-29 02:52:37',1);
