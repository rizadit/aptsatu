INSERT INTO R_JENISTIKET (URAIAN_JENISTIKET) VALUES
	 ('Pertanyaan\r\nPertanyaan'),
	 ('Pengaduan dugaan pelanggaran peraturan perundang-undangan di bidang kekayaan negara, penilaian dan lelang oleh masyarakat'),
	 ('Pengaduan pelayanan dan sarana prasarana'),
	 ('Pengaduan pelanggaran kode etik/disipilin pegawai'),
	 ('Keluhan'),
	 ('Saran'),
	 ('Permintaan atas layanan sesuai dengan katalog layanan');
