INSERT INTO R_JENISPENGGUNA (ID_JENISPENGGUNA,URAIAN_JENISPENGGUNA) VALUES
	 (15861,'Orang Perseorangan\r\nOrang Perseorangan'),
	 (15862,'Badan Publik'),
	 (15863,'Badan Hukum'),
	 (15864,'Organisasi Kemasyarakatan');
