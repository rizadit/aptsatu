INSERT INTO R_JENISPRIORITAS (ID_JENISPRIORITAS,URAIAN_JENISPRIORITAS) VALUES
	 (15847,'Sangat Tinggi (Urgen)'),
	 (15848,'Tinggi'),
	 (15849,'Sedang'),
	 (15850,'Biasa'),
	 (15851,'Rendah');
