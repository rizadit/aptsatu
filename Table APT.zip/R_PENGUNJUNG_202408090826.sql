INSERT INTO R_PENGUNJUNG (TELEPON,NIP_NIK,NAMA,EMAIL,INSTANSI_UNIT,ID_KANTOR) VALUES
	 ('08999','6271031608700006','Rizky','rizadit99@gmail.com','15861',3),
	 ('089603182875','622222','Alwi Maulana','test@example.us','15863',3508080307),
	 ('089603182875','622222','Alwi Maulana','test@example.us','15861',28),
	 ('089999','622222','Heri Muhammad','ejemplo@ejemplo.mx','15861',1),
	 ('08999','622222','Rizky','test@beispiel.de','15864',1),
	 ('089999','622222','David Drianysah','test@example.us','15861',1),
	 ('08999','622222','Rizky','test@example.us','15861',1),
	 ('08999','622222','Rizky','teste@exemplo.us','15861',1),
	 ('08999','622222','Rizky','test@example.us','15861',1),
	 ('08999','622222','Rizky','teste@exemplo.us','15861',1);
INSERT INTO R_PENGUNJUNG (TELEPON,NIP_NIK,NAMA,EMAIL,INSTANSI_UNIT,ID_KANTOR) VALUES
	 ('08999','622222','Rizky','test@example.us','15861',1),
	 ('08999','622222','Rizky','teste@exemplo.us','15861',1),
	 ('089603182875','622222','Rizky','teste@exemplo.us','15861',1),
	 ('08999','622222','Rizky','test@example.us','15861',1),
	 ('08999','622222','Rizky f','teste@exemplo.us','15861',1),
	 ('08999','622222','Rizky','test@example.us','15861',1),
	 ('08999','622222','Rizky','test@example.us','15861',1),
	 ('08999','622222','Alwi Maulana','test@example.us','15861',1),
	 ('08999','622222','heri maulana','rizadit99@gmail.com','15861',1),
	 ('089603182875','622222','Heri Muhammad','rizadit99@gmail.com','15861',3508090202);
INSERT INTO R_PENGUNJUNG (TELEPON,NIP_NIK,NAMA,EMAIL,INSTANSI_UNIT,ID_KANTOR) VALUES
	 ('089603182875','622222','Heri Muhammad','rizadit99@gmail.com','15861',3508090202),
	 ('089603182875','622222','Heri Muhammad','rizadit99@gmail.com','15861',350809),
	 ('089603182875','622222','Heri Muhammad','rizadit99@gmail.com','15861',350809);
