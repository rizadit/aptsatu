INSERT INTO R_JENISLAYANAN (URAIAN_JENISLAYANAN,ID_DEPARTEMEN) VALUES
	 ('Kontak DJKN dan kantor vertikal',759),
	 ('Konfirmasi data pegawai',759),
	 ('Penawaran jasa',759),
	 ('Konsultasi terkait kepegawaian/HRIS/Nadine',759),
	 ('Permohonan data untuk riset',759),
	 ('Prosedur magang/PKL',759),
	 ('Pembagian wilayah kerja DJKN',759),
	 ('Konsultasi terkait kepatuhan internal',759),
	 ('Konsultasi terkait ISO/Kepuasan Pengguna layanan',759),
	 ('Konsultasi terkait penyetoran kas negara',759);
INSERT INTO R_JENISLAYANAN (URAIAN_JENISLAYANAN,ID_DEPARTEMEN) VALUES
	 ('Konsultasi terkait PUG',759),
	 ('Konsultasi terkait hal-hal lain lingkup Departemen Sekretariat DJKN',759),
	 ('Konsultasi terkait pengadaan',759),
	 ('Kontak Kantor Vertikal',15308),
	 ('Permintaan Jadwal Temu Dengan Petugas KPKNL',15308),
	 ('Konsultasi Penatausahaan BMN',15308),
	 ('Konsultasi Perencanaan BMN',15308),
	 ('Konsultasi Pemindahtanganan/Penghapusan BMN',15308),
	 ('Konsultasi Pemanfaatan BMN',15308),
	 ('Konsultasi Sertifikasi BMN',15308);
INSERT INTO R_JENISLAYANAN (URAIAN_JENISLAYANAN,ID_DEPARTEMEN) VALUES
	 ('SIMAN UAKPB',15308),
	 ('Progam Keringanan Utang',15308),
	 ('Konsultasi Penilaian BMN/BMD',15308),
	 ('Konsultasi Laporan Penilaian BMN',15308),
	 ('Permintaan Pengembalian Uang Jaminan',15308),
	 ('Konfirmasi Kesalahan Transfer Uang Jaminan Lelang (VA/Nominal Jaminan)',15308),
	 ('Permintaan Verifikasi KTP dan/atau NPWP',15308),
	 ('Konfirmasi Alasan KTP dan/atau NPWP Ditolak',15308),
	 ('Permintaan Verifikasi Uang Jaminan',15308),
	 ('Permintaan Verifikasi Status Kepesertaan',15308);
INSERT INTO R_JENISLAYANAN (URAIAN_JENISLAYANAN,ID_DEPARTEMEN) VALUES
	 ('Konfirmasi Alasan Kepesertaan Lelang Ditolak',15308),
	 ('Konfirmasi Mengenai Objek/ Pelaksanaan Lelang',15308),
	 ('Konsultasi Pengajuan Permohonan Lelang Online',15308),
	 ('Prosedur Penjualan melalui Lelang',15308),
	 ('Pengaduan Pelaksanaan Lelang',15308),
	 ('Konsultasi Penerbitan Dokumen Pasca Lelang',15308),
	 ('Konsultasi Layanan Lelang',15342),
	 ('Konsultasi Layanan Pengelolaan Kekayaan Negara',15342),
	 ('Konsultasi Layanan Piutang Negara',15342),
	 ('Konsultasi Layanan Penilaian',15342);
INSERT INTO R_JENISLAYANAN (URAIAN_JENISLAYANAN,ID_DEPARTEMEN) VALUES
	 ('Layanan Dukungan Lain-Lain',15342),
	 ('Konsultasi Mengenai Pengurusan Piutang Negara Selaku PUPN Cabang',15308);
